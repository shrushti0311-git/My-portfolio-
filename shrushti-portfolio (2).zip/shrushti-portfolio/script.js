/* ===== EDIT YOUR CONTACT DETAILS HERE (leave "" to hide) ===== */
const CONFIG = {
  email: "",
  linkedin: "https://www.linkedin.com/in/shrushti-shewale-433951450",
  github: "",
  instagram: ""
};

/* ---------- Hero reveal spotlight ---------- */
const hero = document.getElementById("top");
const reveal = hero.querySelector(".reveal");
const hint = document.getElementById("hint");
const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
const small = () => innerWidth < 700;
let tx = hero.clientWidth * 0.7, ty = hero.clientHeight * 0.4;
let x = tx, y = ty, r = 0, tr = small() ? 110 : 190, idle = true, t0 = performance.now();

function move(e){
  const b = hero.getBoundingClientRect();
  tx = e.clientX - b.left; ty = e.clientY - b.top;
  idle = false; hint.classList.add("gone");
}
hero.addEventListener("pointermove", move);
hero.addEventListener("pointerdown", e => { move(e); tr = small() ? 190 : 330; });
addEventListener("pointerup", () => { tr = small() ? 110 : 190; });
hero.addEventListener("pointerleave", () => { if (!idle) tr = small() ? 110 : 190; });

function frame(now){
  if (idle && !reduce){
    const t = (now - t0) / 1000;
    tx = hero.clientWidth * (0.5 + 0.3 * Math.sin(t * 0.6));
    ty = hero.clientHeight * (0.45 + 0.15 * Math.cos(t * 0.8));
  }
  x += (tx - x) * 0.12; y += (ty - y) * 0.12; r += (tr - r) * 0.1;
  reveal.style.clipPath = `circle(${r}px at ${x}px ${y}px)`;
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);


/* ---------- 3D scene (Three.js): lit, solid objects ---------- */
(function(){
  if (!window.THREE) return;
  const cv = document.getElementById("bg");
  const renderer = new THREE.WebGLRenderer({ canvas: cv, alpha: true, antialias: true });
  renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
  const scene = new THREE.Scene();
  const cam = new THREE.PerspectiveCamera(50, 1, 0.1, 100); cam.position.z = 9;
  scene.add(new THREE.AmbientLight(0xffffff, 0.55));
  const key = new THREE.DirectionalLight(0xffffff, 1.1); key.position.set(4, 5, 6); scene.add(key);
  const rim = new THREE.PointLight(0xb388ff, 2.2, 40); rim.position.set(-5, 2, 4); scene.add(rim);

  function make(geo, color, op, edges){
    const g = new THREE.Group();
    g.add(new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color, metalness: 0.45, roughness: 0.3, flatShading: edges, transparent: op < 1, opacity: op })));
    if (edges) g.add(new THREE.LineSegments(new THREE.EdgesGeometry(geo, 20), new THREE.LineBasicMaterial({ color: 0xe6d6ff, transparent: true, opacity: op < 1 ? 0.5 : 0.85 })));
    return g;
  }
  const defs = [
    { g: make(new THREE.IcosahedronGeometry(2.1, 1), 0x8b5cf6, 1, true), hero: true, dx: 3.4, mx: 0, y: 0.3, my: 1.5 },
    { g: make(new THREE.TorusKnotGeometry(0.8, 0.28, 100, 14), 0xa78bfa, 0.7, false), dx: -5.4, mx: -2.3, y: -3.5 },
    { g: make(new THREE.OctahedronGeometry(1.3), 0x9d6bff, 0.7, true), dx: 5.2, mx: 2.3, y: -7 },
    { g: make(new THREE.TorusGeometry(1.2, 0.4, 16, 40), 0xa78bfa, 0.7, false), dx: -5.2, mx: -2.3, y: -10.5 },
    { g: make(new THREE.IcosahedronGeometry(1.5, 0), 0x9d6bff, 0.7, true), dx: 5.2, mx: 2.3, y: -14 },
    { g: make(new THREE.BoxGeometry(1.6, 1.6, 1.6), 0xa78bfa, 0.7, true), dx: -5.2, mx: -2.3, y: -17 }
  ];
  defs.forEach((d, i) => { d.i = i; d.s = 0.2 + i * 0.05; scene.add(d.g); });

  const N = 200, pos = new Float32Array(N * 3);
  for (let i = 0; i < N; i++){ pos[i*3] = (Math.random()-.5)*18; pos[i*3+1] = -Math.random()*22; pos[i*3+2] = (Math.random()-.5)*10 - 2; }
  const pg = new THREE.BufferGeometry(); pg.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  scene.add(new THREE.Points(pg, new THREE.PointsMaterial({ color: 0xcdb4ff, size: 0.05, transparent: true, opacity: 0.8 })));

  let mx = 0, my = 0, last = performance.now(), lastY = scrollY;
  addEventListener("pointermove", e => { mx = e.clientX / innerWidth - .5; my = e.clientY / innerHeight - .5; });
  function size(){
    renderer.setSize(innerWidth, innerHeight, false); cam.aspect = innerWidth / innerHeight; cam.updateProjectionMatrix();
    const n = innerWidth < 700;
    defs.forEach(d => { d.x = n ? d.mx : d.dx; d.by = d.hero && n ? d.my : d.y; d.g.scale.setScalar(n ? (d.hero ? 0.75 : 0.6) : 1); });
  }
  addEventListener("resize", size); size();

  function loop(now){
    const dt = Math.min((now - last) / 1000, 0.05), t = now / 1000; last = now;
    const max = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    cam.position.y += (-(scrollY / max) * 17 - cam.position.y) * 0.08;
    cam.position.x += (mx * 1.4 - cam.position.x) * 0.05;
    cam.rotation.y = -cam.position.x * 0.04; cam.rotation.x = -my * 0.1;
    rim.position.x = -5 + mx * 8; rim.position.y = 2 - my * 6;
    const sv = scrollY - lastY; lastY = scrollY;
    defs.forEach(d => {
      d.g.position.x = d.x;
      if (reduce) { d.g.position.y = d.by; return; }
      d.g.position.y = d.by + Math.sin(t * 0.8 + d.i) * 0.18;
      d.g.rotation.y += dt * d.s * 1.3 + sv * 0.004;
      d.g.rotation.x += dt * d.s * 0.6 + (d.hero ? (my * 0.6 - 0) * dt : 0);
    });
    renderer.render(scene, cam);
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
})();

/* ---------- Active nav link ---------- */
const links = [...document.querySelectorAll(".nav a")];
const io = new IntersectionObserver(es => es.forEach(e => {
  if (e.isIntersecting) links.forEach(a => a.classList.toggle("on", a.getAttribute("href") === "#" + e.target.id));
}), { rootMargin: "-45% 0px -50% 0px" });
document.querySelectorAll("header[id], section[id]").forEach(s => io.observe(s));

/* ---------- Card tilt (mouse only) ---------- */
if (!reduce) document.querySelectorAll(".tilt").forEach(c => {
  c.addEventListener("pointermove", e => {
    if (e.pointerType !== "mouse") return;
    const b = c.getBoundingClientRect();
    c.style.setProperty("--ry", ((e.clientX - b.left) / b.width - .5) * 10 + "deg");
    c.style.setProperty("--rx", -((e.clientY - b.top) / b.height - .5) * 10 + "deg");
  });
  c.addEventListener("pointerleave", () => { c.style.setProperty("--rx", "0deg"); c.style.setProperty("--ry", "0deg"); });
});

/* ---------- Timeline fills as you scroll ---------- */
const tl = document.getElementById("timeline");
const fill = document.createElement("span"); fill.className = "fill"; tl.prepend(fill);
const items = [...tl.querySelectorAll("li")];
function tick(){
  const b = tl.getBoundingClientRect(), mid = innerHeight * 0.6;
  fill.style.height = Math.max(0, Math.min(b.height - 12, mid - b.top)) + "px";
  items.forEach(li => li.classList.toggle("on", li.getBoundingClientRect().top < mid));
}
addEventListener("scroll", tick, { passive: true }); tick();

/* ---------- Contact links ---------- */
const box = document.getElementById("links");
const defs = [["email", "Email", v => "mailto:" + v], ["linkedin", "LinkedIn", v => v], ["github", "GitHub", v => v], ["instagram", "Instagram", v => v]];
defs.forEach(([k, label, href]) => {
  if (!CONFIG[k]) return;
  const a = document.createElement("a");
  a.href = href(CONFIG[k]); a.textContent = label;
  if (k !== "email") { a.target = "_blank"; a.rel = "noopener"; }
  box.append(a);
});
if (!box.children.length){ const s = document.createElement("span"); s.textContent = "Contact links coming soon"; box.append(s); }

document.getElementById("year").textContent = new Date().getFullYear();
