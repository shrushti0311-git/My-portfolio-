Shrushti's portfolio
- Open index.html in any browser.
- Add your email / LinkedIn / GitHub / Instagram at the top of script.js (CONFIG).
- Edit text directly in index.html. Colors are at the top of style.css.
